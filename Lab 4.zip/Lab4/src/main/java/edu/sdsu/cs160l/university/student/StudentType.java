package edu.sdsu.cs160l.university.student;

public enum StudentType {
    UNDER_GRAD,
    GRADUATE
}
